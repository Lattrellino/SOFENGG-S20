package controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.*;

/**
 * Servlet implementation class Admin_Controller
 */
@WebServlet("/Admin_Controller")
public class Admin_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Admin_Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("This is working");
		List<pc_database> pcs = Database.getAllPCs();
		request.getSession().setAttribute("pcs", pcs);
		/*
		
		for(int i = 0; i < pcs.size(); i++){
			for(int j = 0; j < 15; j++){
				available[i][j] = Database.checkIfTimeIsAvail(pcs.get(i).getPcNo(), (7 + i) + ":00", (String) request.getSession().getAttribute("current-day"));
			}
		}
		request.getSession().setAttribute("avail", available);
		 */
		request.getRequestDispatcher("reserve-home.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//================================get parameter=============================//
		//example String username = request.getParameter("username");
		
		String UserID 		= (String)request.getParameter("uer_id");
		String PcNO 		= (String)request.getParameter("pc_no");
		String StartTime 	= (String)request.getParameter("start_time");
		String EndTime 		= (String)request.getParameter("end_time");
		String DateTime	 	= (String)request.getParameter("date_time");
		
		//===============check if the pc is available that time===================//

		//-----------------check pc if available---------------//
		
		if( !Database.checkIfPcAvailable(PcNO) ) {
			response.sendRedirect("/sofengg/Admin_Controller");
			
			//Note : add a popup panel show that the pc isn't available
			
		}
		
		//---------------check time if available-------------//
		
		//if( !Database.checkIfTimeIsAvail( StartTime, EndTime, DateTime)){
			response.sendRedirect("/sofengg/Admin_Controller");
			
			//Note : add a popup panel show that the time isn't available
			
			
		//}
		
		//------------Reserve the time --------------------//
		
		
		
		
				
	}

}
